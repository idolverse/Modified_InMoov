import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from PyQt5.QtWidgets import QApplication
from pyqt_ros_gui.logic.joint_sender import JointSender
from pyqt_ros_gui.ui.joint_gui import JointGUI
import serial

class GUINode(Node):
    def __init__(self,port='COM15', baud=115200):
        super().__init__('gui_joint_publisher')
        self.publisher = self.create_publisher(String, 'processed_joint_states', 10)
        # ❌ 删除以下这行订阅，避免回环/格式不符错误
        # self.subscription = self.create_subscription(String, 'processed_joint_states', self.listener_callback, 10)
        self.gui = None
        self.ser = serial.Serial(port, baud, timeout=1)

    def send_joint_commands(self, joint_data):
        # 构造多行字符串：每行是 joint_name:value
        lines = []
        for joint, info in joint_data.items():
            position = info.get("position", 0) if isinstance(info, dict) else info
            lines.append(f"{joint}:{position}")

        msg = String()
        msg.data = "\n".join(line.strip() for line in lines)

        self.publisher.publish(msg)
        self.get_logger().info(f"✅ Sent joint data:\n{msg.data}")
        for joint, info in joint_data.items():
            position = info.get("position", 0) if isinstance(info, dict) else info
            line = f"{joint}:{position}\n"
            self.ser.write(line.encode('utf-8'))
            print(f"✅ 发送: {line.strip()}")

    # 如果你有用 JSON 监听别的 Topic，可启用
    # def listener_callback(self, msg):
    #     try:
    #         data = json.loads(msg.data)
    #         if self.gui:
    #             self.gui.update_joint_states({k: v['position'] for k, v in data.items()})
    #     except Exception as e:
    #         self.get_logger().error(f"Failed to parse incoming JSON: {e}")

def main():
    rclpy.init()
    node = GUINode()
    logic = JointSender(node)

    app = QApplication([])
    gui = JointGUI(sender=node, logic=logic)
    node.gui = gui
    logic.ui = gui
    gui.show()

    from threading import Thread
    ros_thread = Thread(target=rclpy.spin, args=(node,), daemon=True)
    ros_thread.start()

    app.exec()
    node.destroy_node()
    rclpy.shutdown()
